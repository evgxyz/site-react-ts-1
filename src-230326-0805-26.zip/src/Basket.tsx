
import React, {useReducer} from 'react';

export interface TBasketState {
  count: number
}

export enum TBasketActionTypes { inc = 1, dec = -1 }

export interface TBasketAction {
  type: TBasketActionTypes,
  value?: any
}

export type TBasketDispatch = React.Dispatch<TBasketAction>;

function basketReducer(state: TBasketState, action: TBasketAction) {
  switch (action.type) {
    case TBasketActionTypes.inc: 
      return { ...state, count: state.count + 1 }
    case TBasketActionTypes.dec: 
      return { ...state, count: state.count - 1 }
    default: 
      return state;
  }
}

const BasketInitState: TBasketState = {
  count: 0
}

export function useBasketReducer(): [TBasketState, TBasketDispatch] {
  return useReducer(basketReducer, BasketInitState);
}

interface TBasketTrayProps {
  basketState: TBasketState,
  basketDispatch: TBasketDispatch
}

export function BasketTray(props: TBasketTrayProps) {
  return (
    <div>
      В корзине {props.basketState.count} товаров
    </div>
  );
}
