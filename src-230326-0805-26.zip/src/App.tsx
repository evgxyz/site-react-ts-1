
import React, {useState} from 'react';
import {BasketTray, useBasketReducer} from './Basket'
import {ProductCard} from './ProductCard'

function App() {

  const [basketState, basketDispatch] = useBasketReducer();

  return (
    <>
    <div className={'header'}>
      <BasketTray basketState={basketState} basketDispatch={basketDispatch} />
    </div>
    <div className={'main'}>
      <ProductCard basketState={basketState} basketDispatch={basketDispatch} />
    </div>
    </>
  );
}

export default App;
