
import React, {useState} from 'react';
import {TBasketState, TBasketDispatch, TBasketActionTypes} from './Basket'

export interface TProductCardProps {
  basketState: TBasketState,
  basketDispatch: TBasketDispatch
}

export function ProductCard(props: TProductCardProps) {

  const handlerIncrement = function() {
    props.basketDispatch({type: TBasketActionTypes.inc});
  }

  const handlerDecrement = function() {
    props.basketDispatch({type: TBasketActionTypes.dec});
  }

  return (
    <div>
      <div>{props.basketState.count}</div>
      <button onClick={handlerIncrement}>Добавить</button>
      <button onClick={handlerDecrement}>Убавить</button>
    </div>
  );
}
