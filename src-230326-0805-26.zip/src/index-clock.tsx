import React from 'react';
import ReactDOM from 'react-dom/client';
import { clearInterval } from 'timers';

interface MyProps {
  message: string;
}

interface MyState {
  date: Date; 
}

class Example extends React.Component<MyProps, MyState> {

  timerId: ReturnType<typeof setTimeout> | undefined = undefined;

  constructor(props: MyProps) {
    super(props);
    
    this.state = {
      date: new Date(),
    }
  }

  componentDidMount(): void {
    this.timerId = setInterval(
      () => this.tick(),
      1000
    );
  }

  componentWillUnmount(): void {
    clearInterval(this.timerId);
  }

  tick(): void {
    this.setState({ date: new Date() })
  }

  render() {
    return (
      <div>
        <h1>{this.props.message}</h1>
        <h2>{this.state.date.toLocaleTimeString()}</h2>
      </div>
    );
  }
}

const root = ReactDOM.createRoot(document.getElementById('root') as HTMLElement);
root.render(
  <Example message="Hello!" />
)
