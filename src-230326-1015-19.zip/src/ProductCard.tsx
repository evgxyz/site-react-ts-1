
import React, {useState} from 'react';
import {TBasketControl, TBasketActionTypes} from './Basket'

export interface TProductCardProps {
  basketControl: TBasketControl
}

export function ProductCard(props: TProductCardProps) {

  const handlerIncrement = function() {
    props.basketControl.dispatch({type: TBasketActionTypes.inc});
  }

  const handlerDecrement = function() {
    props.basketControl.dispatch({type: TBasketActionTypes.dec});
  }

  return (
    <div>
      <div>{props.basketControl.state.count}</div>
      <button onClick={handlerIncrement}>Добавить</button>
      <button onClick={handlerDecrement}>Убавить</button>
    </div>
  );
}
