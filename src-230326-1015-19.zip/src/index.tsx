import React, {useState} from 'react';
import ReactDOM from 'react-dom/client';
import App from './App'

const root = ReactDOM.createRoot(document.getElementById('root') as HTMLElement);

window.addEventListener(
  'hashchange', 
  (ev) => { 
    const newUrlHash = (new URL(ev.newURL)).hash;
    const oldUrlHash = (new URL(ev.oldURL)).hash;

    if (newUrlHash == '' || /^\#\!/.test(newUrlHash) || oldUrlHash == '' || /^\#\!/.test(oldUrlHash)) {
      window.location.reload() 
    }
  }
);

const urlHash = window.location.hash ?? '';

let rootBody = (
  <>
    <h1>Main page</h1>
    <div><a href="#!catalog">Каталог</a></div>
    <div><a href="#catalog2">Каталог2</a></div>
    <div><a href="#!admin">Админка</a></div>
  </>
)

if (urlHash == '#!catalog') {
  rootBody = <App/>
} 
else 
if (urlHash == '#!admin') {
  rootBody = <h1>Админка</h1>
}

root.render(rootBody)
