
import React from 'react';
import {BasketTray, useBasketReducer} from './Basket'
import {ProductCard} from './ProductCard'

function App() {

  const basketControl = useBasketReducer();

  return (
    <>
    <div className={'header'}>
      <BasketTray basketControl={basketControl} />
    </div>
    <div className={'main'}>
      <ProductCard basketControl={basketControl} />
    </div>
    </>
  );
}

export default App;
