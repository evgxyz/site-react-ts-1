
export interface TBasketState {
  count: number
}
  
export type TSetBasketState = React.Dispatch<React.SetStateAction<TBasketState>>;

export interface TBasketTrayProps {
  basketState: TBasketState,
  setBasketState: TSetBasketState
}
