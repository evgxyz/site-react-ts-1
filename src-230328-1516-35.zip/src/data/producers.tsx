
import {TProducer} from '../units/Products'

export const initProducers: TProducer[] = [
  {
    "id": 1,
    "title": "P&G"
  },
  {
    "id": 2,
    "title": "Tide"
  }
];