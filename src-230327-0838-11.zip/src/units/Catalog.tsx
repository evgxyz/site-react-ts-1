
import React, {useState, useEffect} from 'react';
import {TBasketControl} from './Basket'
import {TProduct, ProductCard} from './Product'
import {productsInit} from '../data/products'

export interface TCatalogProps {
  basketControl: TBasketControl
}

export function Catalog(props: TCatalogProps) {

  const [products, setProducts] = useState([] as TProduct[]);

  async function fetchProducts() {
    const products: TProduct[] = JSON.parse(String(localStorage.getItem('products'))) ?? [];
    setProducts(products);
  }

  useEffect(() => {fetchProducts()}, [])

  return (
    <div>
      {products.map((product) => 
        <ProductCard key={product.id} product={product} basketControl={props.basketControl}/>
      )}
    </div>
  );
}

if( !localStorage.getItem('products') ) {
  localStorage.setItem('products', JSON.stringify(productsInit));
}