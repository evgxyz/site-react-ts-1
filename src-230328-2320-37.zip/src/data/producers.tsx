
import {TProducer} from '../units/Products'

export const initProducers: TProducer[] = [
  {
    "id": 1,
    "title": "Vanish"
  },
  {
    "id": 2,
    "title": "Tide"
  }
];