
import React, {useState, useEffect} from 'react';
import {TBasketControl} from './Basket'
import {TProduct, ProductCard} from './Product'
import {productsInit} from '../data/products'

interface TFilterParams {
  priceFr: number,
  priceTo: number
}

const initFilterParams: TFilterParams = {
  priceFr: 0,
  priceTo: 10000
}

const initProductList: TProduct[] = [];

export interface TCatalogProps {
  basketControl: TBasketControl
}

export function Catalog(props: TCatalogProps) {

  const [filterParams, setFilterParams] = useStateMerge(initFilterParams);
  const [productList, setProductList] = useState(initProductList);

  async function updateProductList() {
    const newProductList = await fetchProducts(filterParams);
    setProductList(newProductList);
  }

  useEffect(() => {updateProductList()}, [filterParams]);

  return (
    <div className='catalog'>
      <div>{JSON.stringify(filterParams, null, 2)}</div>
      <div className='catalog__filter'>
        <ProductFilter filterParamsControl={[filterParams, setFilterParams]} />
      </div>
      <div className='catalog__results'>
        {productList.map((product) => 
          <ProductCard key={product.id} product={product} basketControl={props.basketControl} />
        )}
      </div>
    </div>
  );
}

interface TProductFilterProps {
  filterParamsControl: [TFilterParams, (v: TFilterParams) => void]
}

function ProductFilter(props: TProductFilterProps) {

  const [filterParams, setFilterParams] = props.filterParamsControl;

  const [priceFr, setPriceFr] = useState('0');
  const [priceTo, setPriceTo] = useState('1000');

  function formOnSubmit(ev: React.SyntheticEvent) {
    ev.stopPropagation();
 
    setFilterParams({
      priceFr: parseInt(priceFr),
      priceTo: parseInt(priceTo),
    });
  }

  function priceFrOnChange(ev: React.FormEvent<HTMLInputElement>) {
    setPriceFr(ev.currentTarget.value);
  }

  function priceToOnChange(ev: React.FormEvent<HTMLInputElement>) {
    setPriceTo(ev.currentTarget.value);
  }

  return (
    <form className='filter__form' onSubmit={formOnSubmit}>
      <div className='filter__price'>
        <input type='text' value={priceFr} onChange={priceFrOnChange} />
        <input type='text' value={priceTo} onChange={priceToOnChange} />
      </div>
      <button type='submit'>Показать</button>
    </form>
  );
}

async function fetchProducts(filterParams: TFilterParams) {
  const products: TProduct[] = JSON.parse(String(localStorage.getItem('products'))) ?? [];
  const filteredProducts = products.filter(product => {
    return (
      product.price >= filterParams.priceFr && product.price <= filterParams.priceTo
    );
  })
  return filteredProducts;
}


/* function inputOnChange<T = string | number>(
    ev: React.FormEvent<HTMLInputElement>, 
    setValue: (v: T) => void,
    type: string = 'string'
  ): void {
  setValue(type === 'number' ? Number(ev.currentTarget.value) : ev.currentTarget.value);
} */

function useStateMerge<T>(initValue: T) {
  const [value, setValue] = useState(initValue);
  const setValueMerge = function(value: T): void {
    setValue(prevValue => ({...prevValue, ...value}));
  }
  return [value, setValueMerge] as [T, (v: T) => void];
}

// инициализация набора продуктов
if( !localStorage.getItem('products') ) {
  localStorage.setItem('products', JSON.stringify(productsInit));
}